#!/usr/bin/perl -w

# Runs TreeTagger once for each sentence. Designed to be used in a pipeline.
# Assumes tree-tagger is given options "-token -lemma -sgml -pt-with-lemma
# -threshold 0.5 -prob"
# Slow for batch processing.

#use lib "$ENV{HOME}/delphin/lib/perl5/site_perl/5.8.8";
use Delphin::FSPP;

my $lang="german";
my $punctTagRE = qr/^\$/;
my $TreeTaggerDir = "$ENV{HOME}/src/TreeTagger";

sub output_tokens($$)
{
   my ($sentnum, $toks) = @_;
	open(OUT, ">-");
   print OUT "<?xml version=\"1.0\" encoding=\"utf-8\" ?>\n";
   print OUT "<!DOCTYPE pet-input-chart\n";
   print OUT "  SYSTEM \"/home/HU/rdrid/pic.dtd\">\n";
   print OUT "<pet-input-chart>\n";

   my $tokno = 1;
   foreach my $t (@{$toks->{'tokens'}})
   {
      print OUT "<w id=\"TT$tokno\" cstart=\"".$t->{'cfrom'}."\" cend=\""
         .$t->{'cto'}."\">\n";
      print OUT "\t<surface>".$t->{'surface'}."</surface>\n";
      foreach my $pos (keys %{$t->{'pos'}})
      {
         print OUT "\t<pos tag=\"$pos\" prio=\"".$t->{'pos'}->{$pos}."\"/>\n";
      }
      print OUT "</w>\n";
      $tokno++;
   }
   print OUT "</pet-input-chart>\n\n";
   close OUT;
}


my $TT_cmd = "iconv -f utf8 -t latin1 |$TreeTaggerDir/cmd/tree-tagger-$lang|"
	."iconv -f latin1 -t utf8";
my $fn = shift @ARGV or die "Usage: $0 <fsr filename>:$!\n";
my $fspp = Delphin::FSPP->new($fn);

my $sentno = 1;
while(<>)
{
	chomp;
	my $sent = $_;

	my $toks = $fspp->process($sent);
	my $charpos = 0;
	open(TTRES, "echo \"$sent\" |$TT_cmd|") or die "Couldn run TT:$!\n";
	while(<TTRES>)
	{
		chomp;
		my @fields = split /\s/;
		my $lemma = $fields[0];
		my @realtoks;
		my $cfrom = index $sent, $lemma, $charpos;
		my $cto = $cfrom + (length $lemma);
		$charpos = $cto;
		for(my $i=$cfrom; $i <= $cto; $i++)
		{
			if(! @realtoks or $realtoks[$#realtoks] != $toks->{'mapping'}->[$i])
			{
				push @realtoks, $toks->{'mapping'}->[$i]; 
			}
		}
		for(my $i=1; $i <= $#fields; $i+=3)
		{
			my $pos = $fields[$i];
			my $prob = $fields[$i+2];
			next if($pos=~/$punctTagRE/); #don't use punct POS tags
			foreach my $rt (@realtoks)
			{
				$toks->{'tokens'}->[$rt]->{'pos'} = {} 
					unless exists $toks->{'tokens'}->[$rt]->{'pos'};
				unless(exists $toks->{'tokens'}->[$rt]->{'pos'}->{$pos})
				{
					$toks->{'tokens'}->[$rt]->{'pos'}->{$pos} = $prob;
				}
			}
		}
	}

	output_tokens($sentno,$toks);
	$sentno++;
}
	
