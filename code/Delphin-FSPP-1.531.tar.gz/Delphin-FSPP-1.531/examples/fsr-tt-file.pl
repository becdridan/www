#!/usr/bin/perl -w

# Runs TreeTagger once on the entire input file. Much faster for batch
# processing than sentence by sentence, but apparently can't be run on very 
# large files. So far, no problem with 300,000 sentence files.
# Assumes tree-tagger is given options "-token -lemma -sgml -pt-with-lemma
# -threshold 0.5 -prob"

#use lib "$ENV{HOME}/delphin/lib/perl5/site_perl/5.8.8";
use Delphin::FSPP;
my $TreeTaggerDir = "$ENV{HOME}/src/TreeTagger";

my $lang="german";
my $punctTagRE = qr/^\$/;

sub output_tokens($$)
{
	my ($sentnum, $toks) = @_;
#	my $outfile = sprintf "%08d.xml", $sentnum;
#	open(OUT, ">$outfile") or die "Couldn't open $outfile for writing:$!\n";
	open(OUT, ">-") or die "Couldn't write to STDOUT:$!\n";
   print OUT "<?xml version=\"1.0\" encoding=\"utf-8\" ?>\n";
   print OUT "<!DOCTYPE pet-input-chart\n";
   print OUT "  SYSTEM \"/home/HU/rdrid/pic.dtd\">\n";
   print OUT "<pet-input-chart>\n";

	my $tokno = 1;
	foreach my $t (@{$toks->{'tokens'}})
	{
		print OUT "<w id=\"TT$tokno\" cstart=\"".$t->{'cfrom'}."\" cend=\""
			.$t->{'cto'}."\">\n";
		print OUT "\t<surface>".$t->{'surface'}."</surface>\n";
		foreach my $pos (keys %{$t->{'pos'}})
		{
			print OUT "\t<pos tag=\"$pos\" prio=\"".$t->{'pos'}->{$pos}."\"/>\n";
		}
		print OUT "</w>\n";
		$tokno++;
	}
	print OUT "</pet-input-chart>\n\n";
	close OUT;
}

my $TT_cmd = "perl -ne 's/^(.*)\$/\$1 <SENT>/;print;'| iconv -f utf8 -t latin1"
	."|$TreeTaggerDir/cmd/tree-tagger-$lang|iconv -f latin1 -t utf8";
my $fn = shift @ARGV or die "Usage: $0 <fsr file> <input file>:$!\n";
my $input = shift @ARGV or die "Usage: $0 <fsr file> <input file>:$!\n";
my $fspp = Delphin::FSPP->new($fn);

open(INPUT, "<$input") or die "Couldn't open $input for reading:$!\n";
my $sentno = 1;
my $sent = <INPUT>;
my $charpos = 0;
chomp $sent;
my $toks = $fspp->process($sent);
open(TTRES, "cat $input |$TT_cmd|") or die "Couldn't run TT:$!\n";
while(<TTRES>)
{
	chomp;
	if(/<SENT>/)
	{
		output_tokens($sentno,$toks);
		$sent = <INPUT>;
		last if not $sent;
		$charpos = 0;
		$sentno++;
		chomp $sent;
		$toks = $fspp->process($sent);
		next;
	}
	my @fields = split /\s/;
	my $lemma = $fields[0];
	my @realtoks;
	my $cfrom = index $sent, $lemma, $charpos;
	my $cto = $cfrom + (length $lemma);
	$charpos = $cto;
	for(my $i=$cfrom; $i <= $cto; $i++)
	{
		next if not defined $toks->{'mapping'}->[$i];
		if(! @realtoks or $realtoks[$#realtoks] != $toks->{'mapping'}->[$i])
		{
			push @realtoks, $toks->{'mapping'}->[$i]; 
		}
	}
	for(my $i=1; $i <= $#fields; $i+=3)
	{
		my $pos = $fields[$i];
		my $prob = $fields[$i+2];
		next if($pos=~/$punctTagRE/); #don't use punct POS tags
		foreach my $rt (@realtoks)
		{
			$toks->{'tokens'}->[$rt]->{'pos'} = {} 
				unless exists $toks->{'tokens'}->[$rt]->{'pos'};
			unless(exists $toks->{'tokens'}->[$rt]->{'pos'}->{$pos})
			{
				$toks->{'tokens'}->[$rt]->{'pos'}->{$pos} = $prob;
			}
		}
	}
}

close TTRES or warn "Something odd happened to tt:$!\n";
close INPUT;

