#!/usr/bin/perl -w

use Delphin::FSPP;
use strict;

die "Usage: $0 <preprocessor file> <sentence file>\n" if($#ARGV != 1);
my $fspp = Delphin::FSPP->new($ARGV[0]);
my $sentfile = $ARGV[1];
open(IN, "<$sentfile") or die "quack:$!\n";
while(<IN>)
{
	chomp;
	my $s = $_;
	my $res = $fspp->process($s);

	foreach my $t (@{$res->{'tokens'}})
	{
#		print "-$t-\n";
		print "\"".$t->{'surface'}."\" (".$t->{'cfrom'}."-".$t->{'cto'}.")\n";
	}

	print "next\n";
}
