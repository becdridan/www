#!/usr/bin/perl -w

use Delphin::FSPP;
use strict;

die "Usage: $0 <preprocessor file>\n" if($#ARGV != 0);
my $fspp = Delphin::FSPP->new($ARGV[0]);

print "Loaded $ARGV[0]\n";
