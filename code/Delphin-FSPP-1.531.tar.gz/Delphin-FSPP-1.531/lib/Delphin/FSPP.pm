package Delphin::FSPP;

use 5.008;
use strict;
use warnings;
use Carp;

require Exporter;
use AutoLoader qw(AUTOLOAD);

our @ISA = qw(Exporter);

# Items to export into callers namespace by default. Note: do not export
# names by default without a very good reason. Use EXPORT_OK instead.
# Do not simply export all your public functions/methods/constants.

our @EXPORT_OK = ( );
our @EXPORT = qw( );

our $VERSION = sprintf "1.%d",q$Revision: 531 $ =~ /: (\d+)/;

sub new {
	my ($pkg, $file) = @_;
	if(! $file)
	{
		croak "No preprocessor file given";
	}

	my %obj = ();

	#rules
	$obj{'replace'} = [];
	$obj{'substitute'} = [];
	$obj{'augment'} = [];
	$obj{'ersatz'} = [];

	#needed for importing files
	$obj{'path'} = "./";
	if($file =~ /^(.*)\/([^\/]+)$/)
	{
		$obj{'path'} = $1 if $1 ne "";
	}

	#default tokenisation by whitespace
	$obj{'tok_regexp'} = qr/[ \t]/;

	#read in the rules
	read_file(\%obj, $file);

	my $fspp = \%obj;
	bless $fspp, $pkg;
	return $fspp;
}

sub process()
{
	my ($o, $sent) = @_;
	my $orgsent = $sent;

	#to keep track of each change
	my $oldsent = $sent;
	my %maps; #maps new token to original token

	#run the global replace rules
	foreach my $rule (@{$o->{'replace'}})
	{
		my $lhs = $rule->{lhs};
		my $rhs = $rule->{rhs};
		$oldsent = $sent;
		my $changes = ($sent =~ s/$lhs/$rhs/eeg);

	# catch global non-whitespace changes, for finding cfroms later
		if($sent ne $oldsent)
		{
			my $stripsent = $sent;
			$stripsent =~ s/$o->{'tok_regexp'}//g;
			my $stripoldsent = $oldsent;
			$stripoldsent =~ s/$o->{'tok_regexp'}//g;
			if($stripoldsent ne $stripsent)
			{
				for(my $c=1; $c <= $changes; $c++)
				{
					if($stripoldsent =~ /^(.*?)($lhs)(.)/)
					{
						my $start = $1;
						$start = escape_str($start);
						my $old = $2;
						my $end = $3;
						$end = escape_str($end);
						$stripsent =~ /^$start(.*?)$end/;
						my $new = $1;
						$new = escape_str($new);
						$maps{$new} = [] if not $maps{$new};
						push @{$maps{$new}}, $old;
						$stripoldsent =~ s/^$start$old(.*)$/$1/;
						$stripsent =~ s/^$start$new(.*)$/$1/;
					}
				}
			}
		}
	}

	# now treat tokens separately
	my @toks = split /$o->{'tok_regexp'}/, $sent;
	my @fulltoks = ();
	my $ind = 0;

	foreach my $t (@toks)
	{
		if($t ne "")
		{
			my %tokstruc = ();
			$tokstruc{'surface'} = $t;
			$tokstruc{'original'} = $t;
			#find the original character counts of each token
			my $cfrom = index $orgsent, $t, $ind;
			my $cto = -1;
			#do some fuzzy matching, using the changes caught earlier
			if($cfrom == -1)
			{
				foreach my $n (keys %maps)
				{
					last if $cfrom != -1;
					foreach my $x (@{$maps{$n}})
					{
						my $fuzzytok = $t;
						$fuzzytok =~ s/$n/$x/g;
						$cfrom = index $orgsent, $fuzzytok, $ind;
						last if $cfrom != -1;
					}
				}
			}
			if($cfrom != -1)
			{
				$cto = $cfrom + length $t;
				$ind = $cto;
			}
			$tokstruc{'cfrom'} = $cfrom;
			$tokstruc{'cto'} = $cto;

			foreach my $rule (@{$o->{'substitute'}})
			{
				my $lhs = $rule->{'lhs'};
				my $rhs = $rule->{'rhs'};
				$tokstruc{'surface'} =~ s/$lhs/$rhs/ee;
			}
			foreach my $rule (@{$o->{'augment'}})
			{
				my $lhs = $rule->{'lhs'};
				my $rhs = $rule->{'rhs'};
				my $alt = $tokstruc{'surface'};
				if($alt =~ s/$lhs/$rhs/ee)
				{
					$tokstruc{'alt'} = $alt;
				}
			}
			foreach my $rule (@{$o->{'ersatz'}})
			{
				my $lhs = $rule->{'lhs'};
				my $rhs = $rule->{'rhs'};
				my $ersatz = $tokstruc{'surface'};
				if($ersatz =~ s/$lhs/$rhs/ee)
				{
					$tokstruc{'ersatz'} = $ersatz;
				}
			}
			if(exists $tokstruc{'alt'})
			{
				$tokstruc{'surface'} = $tokstruc{'alt'};
			}
			if(exists $tokstruc{'ersatz'})
			{
				$tokstruc{'surface'} = $tokstruc{'ersatz'};
			}

#			print STDERR "surface is ".tokstruc{'surface'}."\n";
			push @fulltoks, \%tokstruc;
		}
	}

	my @mapping; #character pos to token number
	my $charno;
	my $tokno = 0;
	#TODO repair when cfrom == -1?
	foreach my $t (@fulltoks)
	{
		if($t->{'cfrom'} != -1)
		{
			for($charno=$t->{'cfrom'}; $charno <= $t->{'cto'}; $charno++)
			{
				$mapping[$charno] = $tokno;
			}
		}
		$tokno++;
	}

	#debugging
#	return \@toks;
#	return \@fulltoks;
#
	#return a list of tokens, and a mapping from char position to token number
	my %analysis;
	$analysis{'tokens'} = \@fulltoks;
	$analysis{'mapping'} = \@mapping;
	return \%analysis;
}

sub read_file {
	my ($o, $fn) = @_;

	open(my $in, "<$fn") or croak "Couldn't open $fn for reading:$!\n";

	while(<$in>)
	{
		my $line = $_;
		chomp $line;

		next if($line =~ /^$/); #empty line
		next if($line =~ /^;/); #comment

		if($line =~ /^@/)
		{
			read_version($o, $line);
		}
		elsif($line =~ /^</)
		{
			read_import($o, $line);
		}
		elsif($line =~ /^:/)
		{
			read_tokeniser($o, $line);
		}
		elsif($line =~ /^!/)
		{
         read_rule($o, "replace", $line);
      }
      elsif($line =~ /^-/)
      {
         read_rule($o, "substitute", $line);
      }
      elsif($line =~ /^\+/)
      {
         read_rule($o, "augment", $line);
      }
      elsif($line =~ /^\^/)
      {
         read_rule($o, "ersatz",$line);
      }
      elsif($line =~ /^[>\*]/)
      {
         read_ersatz_arg($line);
      }
      else
      {
         print STDERR "ignoring line \"$line\" as invalid\n";
		}
	}
	close $in;
}

sub read_version()
{
	my ($o, $l) = @_;
	if($l =~ /^@\$(.*)\$$/)
	{
		$o->{'version'} = $1;
	}
	else
	{
		carp "Invalid version string: \"$l\"\n";
	}
}

sub read_import()
{
	my ($o, $l) = @_;
	$l =~ s/<(.*)$/$1/;
	my $fn = $o->{'path'}."/".$l;
	read_file($o, $fn);
}

sub read_tokeniser()
{
	my ($o, $l) = @_;
	$l =~ s/:(.*)$/$1/g;
	$o->{'tok_regexp'} = qr/$l/;
}

sub read_rule()
{
	my ($o, $type, $l) = @_;
	my %rule;
	if($l =~ /^.([^\t]+)\t+([^\t]*)$/)
	{
		$rule{'lhs'} = $1;
	#	$rule{'lhs'} =~ s/\\/\\\\/g;
		my $rhs = $2;
		$rule{'lhs'} = "^".$rule{'lhs'}."\$" if $type ne "replace";
		{
			# make the warning message a bit clearer - I'm pretty sure
			# it means the pattern in the .fsr is invalid
			local $SIG{__WARN__} = 
				sub{
					my $warn = $_[0];
					$warn =~ s/at (\S+) line \d+, <([^>]*)>/ at/;
					warn "Warning: invalid pattern in preprocessor file: \n$warn"
						." Skipping.\n";
				};
		$rule{'lhs'} = qr/$rule{'lhs'}/;
		}
		$rhs =~ s/"/\\"/g;
		our @ms = ();
		$rhs =~ s/\\(\d+)(?{ push @ms, $1; })/\%s/g;
		$rule{'rhs'} = "sprintf \"$rhs\"";
		foreach my $m (@ms)
		{
			$rule{'rhs'} .= ",\$$m" if $m ne "";
		}
		$rule{'rhs'} .= ";";

		push @{$o->{'replace'}}, \%rule if $type eq "replace";
		push @{$o->{'substitute'}}, \%rule if $type eq "substitute";
		push @{$o->{'augment'}}, \%rule if $type eq "augment";
		push @{$o->{'ersatz'}}, \%rule if $type eq "ersatz";

	#debug
	#print "rule: \"".$rule{lhs}." -> ".$rule{rhs}."\"\n" if $type eq "replace";
	}
}

#unimplemented so far
sub read_ersatz_arg()
{
	my ($o, $l) = @_;
}

# escape strings that will be used in regexps
sub escape_str()
{
	my $str = $_[0];
	$str =~ s/\\/\\\\/g;
	$str =~ s/\//\\\//g;
	$str =~ s/([{}[\]()\^\$.|*+?])/\\$1/g;

	return $str;
}

1;
__END__

=head1 NAME

Delphin::FSPP - Perl module to tokenise a sentence according to the finite state
rules in the preprocesser.fsr files in DELPH-IN grammars. Emulates the LISP
functionality, but tries to keep track of the original character spans.

=head1 SYNOPSIS

  use Delphin::FSPP;
  
  my $fspp = Delphin::FSPP->new($preprocessor_filename);

  while(<>)
  {
   chomp;
   $res = $fspp->process($_);

   foreach my $t (@{$res->{'tokens'}})
   {
    print $t->{'surface'}." (".$t->{'cfrom'}."-".$t->{'cto'}.")\n";
   }

   print "The token that covers character position 3 is: ";
   my $tokno = $res->{'mapping'}->[3];
   print "$tokno: ".$res->{'tokens'}->[$tokno]->{'surface'}."\n";
  } 

=head1 DESCRIPTION

This module emulates the LISP finite state tokenisation machinery currently used
in LKB and PET. For those who need a richer input format that string, but still
wish to have the expected tokenisation.

 new() needs the .fsr file from the grammar and returns an FSPP object

 process() takes the FSPP object and a sentence, and returns a structure
 containing a list of tokens (with their surface form, original form and
 character counts), and a list that maps from character position to token
 number.

=head2 EXPORT

None by default.

=head1 SEE ALSO

Information about the grammars and tools that process them at
http://wiki.delph-in.net.

=head1 AUTHOR

Rebecca Dridan, E<lt>rdrid@dridan.comE<gt>

=head1 COPYRIGHT AND LICENSE

Copyright (C) 2008 by Rebecca Dridan

This library is free software; you can redistribute it and/or modify
it under the same terms as Perl itself, either Perl version 5.8.6 or,
at your option, any later version of Perl 5 you may have available.


=cut
