package Delphin::Matcher;

use 5.008;
use strict;
use warnings;

use Delphin::RMRS;
use Encode;

require Exporter;

our @ISA = qw(Exporter);

our %EXPORT_TAGS = ( );
our @EXPORT_OK = ( );
our @EXPORT = qw( );

our $VERSION = sprintf "%d.%03d", q$Revision: 1.8 $ =~ /: (\d+)\.(\d+)/;

sub new {
	my ($pkg,$a,$b,$c) = @_;
	my %scores = ();
	$scores{'name'} = $pkg;
	$scores{'POSMismatch'} = $a;
	$scores{'SenseMismatch'} = $b;
	$scores{'OrthMismatch'} = $c;

	my $obj = \%scores;
	bless $obj, $pkg;

	return $obj;
}

sub getName {
	my $obj = $_[0];
	return $obj->{'name'};
}
sub precondition {
	return 1;
}

sub match {
	my ($obj, $rmrs1, $lbl1, $word1, $rmrs2, $lbl2, $word2) = @_;
	my %match = ();
	my ($base1,$pos1,$sd1) = split /_/, $rmrs1->getRelByLabel($lbl1);
	my ($base2,$pos2,$sd2) = split /_/, $rmrs2->getRelByLabel($lbl2);

	if($base1 eq "generic" or $base2 eq "generic")
	{
		if($base1 eq "generic")
		{
			$pos1 = substr($pos1, 0, 1);
		}
		if($base2 eq "generic")
		{
			$pos2 = substr($pos2, 0, 2);
		}
	}
	if(defined $rmrs1->getCARGByLabel($lbl1) and defined
		$rmrs2->getCARGByLabel($lbl2))
	{
		my $carg1 = $rmrs1->getCARGByLabel($lbl1);
		my $carg2 = $rmrs2->getCARGByLabel($lbl2);
		if($carg1 eq $carg2)
		{
			$match{'match'} = "EXACT";
			$match{'score'} = 0;
			if($word1 ne $word2)
			{
				$match{'score'} += $obj->{'OrthMismatch'};
			}
		}
		elsif($word1 eq $word2)
		{
			$match{'match'} = "EXACT";
			$match{'score'} = 0;
		}
		else
		{
			$match{'match'} = "NOMATCH";
		}
	}
	else
	{
		if($base1 eq $base2)
		{
			$match{'match'} = "EXACT";
			$match{'score'} = 0;
			if(defined $pos1 and defined $pos2 and $pos1 ne $pos2)
			{
				$match{'score'} += $obj->{'POSMismatch'};
			}
			if(defined $sd1 and defined $sd2 and $sd1 ne $sd2)
			{
				$match{'score'} += $obj->{'SenseMismatch'};
			}
		}
		else
		{
			$match{'match'} = "NOMATCH";
		}
	}
	return \%match;
}

1;
__END__

=head1 NAME

Delphin::Matcher - Matcher object for comparing EPs from Delphin::RMRS objects

=head1 SYNOPSIS

  use Delphin::RMRS;	
  use Delphin::Matcher;

  my $matcher = Delphin::Matcher->new(0.2, 0.2, 0.2);

  if($matcher->precondition($rmrs1->getRelByLabel($lbl)),
  $rmrs2->getRelByLabel($lbl2))
  {
    my $matchresult = $matcher->match($rmrs1, $lbl1, $word1, $rmrs2, 
      $lbl2, $word2);
  }

=head1 DESCRIPTION

A base class for matching EPs from RMRS objects. Different Matcher subclass
objects can be added to a Delphin::Comparator pipeline to allow different
methods of matching between EPs. 

All Matcher classes should have a precondition() method, predicated on relation 
name, which controls whether a match should be attempted, and a match() method
which returns a reference to a matchresult structure. This structure is a hash
with the following keys:

  {match}: description of the match type, eg NOMATCH, EXACT
  {score}: score given to the match, where zero indicates an exact match

This base class matches on relation name, surface form, and CARG value 
if it exists. Only match types of EXACT or NOMATCH can be returned.

The arguments to the constructor set the penalty scores for a mismatch in
part-of-speech, sense and orthography (in case of a CARG match) respectively.

Score for a NOMATCH is undefined.

=head2 EXPORT

None by default.

=head1 SEE ALSO

Delphin::RMRS - defines an RMRS object

Delphin::Comparator - compares two RMRS objects

=head1 BUGS

Allowing all EPs that have a CARG value to match may not be the best decision.
While it is possible to set the word (orthography) mismatch score arbitrarily
high, it will still be labelled as an EXACT match. This may change at a later
date when I decide on the preferred behaviour.

=head1 AUTHOR

Rebecca Dridan, E<lt>rdrid@dridan.comE<gt>

=head1 COPYRIGHT AND LICENSE

Copyright (C) 2006 by Rebecca Dridan

This library is free software; you can redistribute it and/or modify
it under the same terms as Perl itself, either Perl version 5.8.6 or,
at your option, any later version of Perl 5 you may have available.


=cut
