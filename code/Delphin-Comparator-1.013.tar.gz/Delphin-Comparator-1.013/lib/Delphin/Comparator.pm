package Delphin::Comparator;

use 5.008;
use strict;
use warnings;

use Delphin::RMRS;
use Delphin::Matcher;

require Exporter;

our @ISA = qw(Exporter);

our %EXPORT_TAGS = ( );
our @EXPORT_OK = ( );
our @EXPORT = qw( );

our $VERSION = sprintf "%d.%03d", q$Revision: 1.13 $ =~ /: (\d+)\.(\d+)/;

# options
our $entails = 0;

# weights
our $nonEXACTscale = 0.5;
our @argMatch = (-0.5, -0.5, -0.5, -0.5);
our @argUnmatch = (1.5, 1.5, 1.5, 1.5);
our $GpredWeight = 0.1;
our $RealWeight = 1;
our $unmatchedPenalty = 3;

sub new {
	my $pkg = $_[0];
	$entails = $_[1] if defined $_[1];
	my $matcher = Delphin::Matcher->new(0.2, 0.2, 0.2);
	my %obj = ();
	$obj{'Pipeline'} = [$matcher];

	my $comparator = \%obj;
	bless $comparator, $pkg;

	return $comparator;
}
	
sub compare{
	my ($obj, $rmrs1, $rmrs2) = @_;

	unless($rmrs1->isa('Delphin::RMRS') and $rmrs2->isa('Delphin::RMRS'))
	{
		die("Arguments to compare() must be Delphin::RMRS objects");
	}

	my $real1 = $rmrs1->getRealLabels();
	my $real2 = $rmrs2->getRealLabels();

	my @matches = ();
	my %labelsToMatch1 = ();
	my %labelsToMatch2 = ();
	my %arg0ToMatch1 = ();
	my %arg0ToMatch2 = ();
	
	foreach my $lbl1 (@{$real1})
	{
		foreach my $lbl2 (@{$real2})
		{
			my $word1 = $rmrs1->getWord($lbl1);
			my $word2 = $rmrs2->getWord($lbl2);
			my $match = runPipeline($obj, $rmrs1, $lbl1, $word1, $rmrs2, $lbl2, $word2);
		
			if($match->{'match'} ne "NOMATCH")
			{
				$match->{'lbl1'} = $lbl1;
				$match->{'lbl2'} = $lbl2;
				push @matches, $match;
				$labelsToMatch1{$lbl1} = [] if ! defined $labelsToMatch1{$lbl1};
				push @{$labelsToMatch1{$lbl1}}, $#matches;
				$labelsToMatch2{$lbl2} = [] if ! defined $labelsToMatch2{$lbl2};
				push @{$labelsToMatch2{$lbl2}}, $#matches;
				my $arg01 = $rmrs1->getARG0ByLabel($lbl1);
				my $arg02 = $rmrs2->getARG0ByLabel($lbl2);
				$arg0ToMatch1{$arg01} = [] if ! defined $arg0ToMatch1{$arg01};
				push @{$arg0ToMatch1{$arg01}}, $#matches;
				$arg0ToMatch2{$arg02} = [] if ! defined $arg0ToMatch2{$arg02};
				push @{$arg0ToMatch2{$arg02}}, $#matches;
			}
		}
	}

	#all matches stored in @matches
	for(my $m=0; $m <= $#matches; $m++)
	{
		# find associated GPRED EPs
		my $corefs1 = $rmrs1->getLabelsByARG0(
			$rmrs1->getARG0ByLabel($matches[$m]->{'lbl1'}));
		my $corefs2 = $rmrs2->getLabelsByARG0(
			$rmrs2->getARG0ByLabel($matches[$m]->{'lbl2'}));

		my $totalGpreds = 0;
		my $matchedGpreds = 0;
		
		foreach my $e (@{$corefs1})
		{
			if(not $rmrs1->isReal($e))
			{
				$totalGpreds++;
				foreach my $e2 (@{$corefs2})
				{
					if(not $rmrs2->isReal($e2) and $rmrs1->getRelByLabel($e) eq
						$rmrs2->getRelByLabel($e2))
					{
						$totalGpreds++;
						$matchedGpreds++;
						removeFromArray($e, $corefs1);
						removeFromArray($e2, $corefs2);
						last;
					}
				}
			}
		}
		foreach my $e2 (@{$corefs2})
		{
			if(not $rmrs2->isReal($e2))
			{
				$totalGpreds++;
			}
		}

		my $GpredScore = 0;
		$GpredScore = (($totalGpreds - $matchedGpreds)/$totalGpreds)*$GpredWeight 
			if $totalGpreds > 0.0;
		$matches[$m]->{'score'} += $GpredScore;

		# check argument consistency

		my $penalty = 0;

		foreach my $arg (1..4)
		{
			if(my $argx1=$rmrs1->getARGxByLabel($matches[$m]->{'lbl1'},$arg))	
			{
				if(my $argx2=$rmrs2->getARGxByLabel($matches[$m]->{'lbl2'},$arg))	
				{
					#both EPs have an argx
					my @matches1 = (); #matches $argx1 is in
					my @matches2 = (); #matches $argx2 is in
					if($rmrs1->isLabel($argx1))
					{
						@matches1 = @{$labelsToMatch1{$argx1}} if exists
							$labelsToMatch1{$argx1};
						@matches2 = @{$labelsToMatch2{$argx2}} if exists
							$labelsToMatch2{$argx2};
					}
					else
					{
						@matches1 = @{$arg0ToMatch1{$argx1}} if exists
							$arg0ToMatch1{$argx1};
						@matches2 = @{$arg0ToMatch2{$argx2}} if exists
							$arg0ToMatch2{$argx2};
					}
					my %count = ();
					foreach my $match (@matches1, @matches2)
					{
						$count{$match}++;
					}
					my $matchfound = 0;
					foreach my $c (keys %count)
					{
						if($count{$c} > 1)
						{
							$matchfound = 1;
							last;
						}
					}
					if($matchfound)
					{
						$penalty += $argMatch[$arg];
					}
					else
					{
						$penalty += $argUnmatch[$arg];
					}
				}
			}
		}

		my $scale = 1;
		$scale = $nonEXACTscale if $matches[$m]->{'match'} ne "EXACT";
		$matches[$m]->{'score'} += $scale*$penalty;
		$matches[$m]->{'score'} = 0 if $matches[$m]->{'score'} < 0;
	}
	#matches and final scores calculated

	# calculate total weight of both RMRSs
	my $totallength = 0;
	my %weights1 = ();
	my $arg0s1 = $rmrs1->getARG0s();
	foreach my $a0 (keys %{$arg0s1})
	{
		$weights1{$a0} = 0;
		my $eps = $arg0s1->{$a0};
		foreach my $l (@{$eps})
		{
			$weights1{$a0}+= $RealWeight if $rmrs1->isReal($l);
		}
		$weights1{$a0} = $GpredWeight if $weights1{$a0} == 0;
		$totallength += $weights1{$a0};
	}
	my %weights2 = ();
	my $arg0s2 = $rmrs2->getARG0s();
	foreach my $a0 (keys %{$arg0s2})
	{
		$weights2{$a0} = 0;
		my $eps = $arg0s2->{$a0};
		foreach my $l (@{$eps})
		{
			$weights2{$a0}+= $RealWeight if $rmrs2->isReal($l);
		}
		$weights2{$a0} = $GpredWeight if $weights2{$a0} == 0;
		$totallength += $weights2{$a0} if !$entails;
	}

	# set up initial set
	my $score = $totallength*$unmatchedPenalty;
	my @sets = ();
	push @sets, {	'STATE' => [ 0 ],
						'ARG01' => \%weights1,
						'ARG02' => \%weights2,
						'SCORE' => $score };
	my $bestset = $sets[0];
	my $bestscore = $score;

	if(exists($matches[0]))
	{
		$score = $score + $matches[0]->{'score'} - 
			$weights1{$rmrs1->getARG0ByLabel($matches[0]->{'lbl1'})} * $unmatchedPenalty;
		unless($entails)
		{
			$score = $score -
			$weights2{$rmrs2->getARG0ByLabel($matches[0]->{'lbl2'})} * $unmatchedPenalty;
		}
		my %newweights1 = %weights1;
		my %newweights2 = %weights2;
		$newweights1{$rmrs1->getARG0ByLabel($matches[0]->{'lbl1'})} = 0;
		$newweights2{$rmrs2->getARG0ByLabel($matches[0]->{'lbl2'})} = 0;
		push @sets, {	'STATE' => [ 1 ],
							'ARG01' => \%newweights1,
							'ARG02' => \%newweights2,
							'SCORE' => $score };
		if($score < $bestscore)
		{
			$bestscore = $score;
			$bestset = $sets[$#sets];
		}

		for(my $m=1; $m <= $#matches; $m++)
		{
			my $mrec = $matches[$m];
			my $slen = $#sets;
			#foreach match, see if adding to previous sets is possible
			for(my $s=0; $s <= $slen; $s++)
			{
				my $weight1 = $RealWeight;
				my $weight2 = $RealWeight;
				my $set = $sets[$s];
				if(exists($sets[$s]))
				{
					if($set->{'ARG01'}->{$rmrs1->getARG0ByLabel($mrec->{'lbl1'})}> 0.0 and
						$set->{'ARG02'}->{$rmrs2->getARG0ByLabel($mrec->{'lbl2'})}> 0.0)
					{ #arg0 not already used in a match
						my @state = ();
						#add match to set
						push @state, @{$set->{'STATE'}}, 1;
						$weight1 =
						$set->{'ARG01'}->{$rmrs1->getARG0ByLabel($mrec->{'lbl1'})};
						$weight2 =
						$set->{'ARG02'}->{$rmrs2->getARG0ByLabel($mrec->{'lbl2'})};
						my $score = $set->{'SCORE'} + $mrec->{'score'} -
							$weight1 * $unmatchedPenalty;
						unless($entails)
						{
							$score -= $weight2 * $unmatchedPenalty;
						}
						#remove the arg0s
						my %newweights1 = %{$set->{'ARG01'}};
						$newweights1{$rmrs1->getARG0ByLabel($mrec->{'lbl1'})} = 0;
						my %newweights2 = %{$set->{'ARG02'}};
						$newweights2{$rmrs2->getARG0ByLabel($mrec->{'lbl2'})} = 0;
						push @sets, {	'STATE' => \@state,
											'ARG01' => \%newweights1,
											'ARG02' => \%newweights2,
											'SCORE' => $score};
						if($score < $bestscore)
						{
							$bestscore = $score;
							$bestset = $sets[$#sets];
						}
					}
					my $threshscore = $set->{'SCORE'}-($weight1*$unmatchedPenalty);
					$threshscore = $set->{'SCORE'}-($weight1) if $m > 31;
					unless($entails)
					{
						$threshscore -= $weight2*$unmatchedPenalty if $m <=31 ;
						$threshscore -= $weight2 if $m > 31;
					}
					if($threshscore <= $bestscore)
					{ # we are only one match away from the best score
						push @{$set->{'STATE'}}, 0;
					}
					else
					{
						delete $sets[$s];
					}
				}
			}
		}
	}
	
	foreach my $a1 (keys %{$bestset->{'ARG01'}})
	{
		if($bestset->{'ARG01'}->{$a1} == $GpredWeight)
		{# unmatched gpred
			if(exists $rmrs1->{'hcons'}->{$a1})
			{# unmatched ARG0 outscopes something
				my $rarg = $rmrs1->getARG0ByLabel($rmrs1->{'hcons'}->{$a1});
				if(defined $rarg and $bestset->{'ARG01'}->{$rarg} == 0)
				{#outscoped pred is matched, look for a matching gpred
					foreach my $m (@{$arg0ToMatch1{$rarg}})
					{
						if($bestset->{'STATE'}->[$m] == 1)
						{
							foreach my $q (keys %{$rmrs2->{'hcons'}})
							{
								if($rmrs2->{'hcons'}->{$q} eq 
									$matches[$m]->{'lbl2'} and defined
									$bestset->{'ARG02'}->{$q}) 
								{
									$bestset->{'SCORE'} -= 
										$bestset->{'ARG01'}->{$a1};
									$bestset->{'SCORE'} -=
										$bestset->{'ARG02'}->{$q} if $entails;
									$bestset->{'ARG01'}->{$a1} = 0;
									$bestset->{'ARG02'}->{$q} = 0;
									$bestscore = $bestset->{'SCORE'};
									last;
								}
							}
						}
					}
				}
			}
			else
			{# doesn't outscope anything, look for matching gpred set
				my @rels = ();
				foreach my $l (@{$rmrs1->getLabelsByARG0($a1)})
				{
					push @rels, $rmrs1->getRelByLabel($l);
				}
				@rels = sort @rels;
				foreach my $a2 (keys %{$bestset->{'ARG02'}})
				{
					if($bestset->{'ARG02'}->{$a2} == $GpredWeight)
					{
						my @rels2 = ();
						foreach my $l (@{$rmrs2->getLabelsByARG0($a2)})
						{
							push @rels2, $rmrs2->getRelByLabel($l);
						}
						@rels2 = sort @rels2;
						if($#rels == $#rels2)
						{
							my $i;
							for($i=0; $i <= $#rels; $i++)
							{
								last if $rels[$i] ne $rels2[$i];
							}
							if($i > $#rels)
							{# matching set
								my $l1 = $rmrs1->getLabelsByARG0($a1)->[0];
								my $l2 = $rmrs2->getLabelsByARG0($a2)->[0];
								push @matches, {	'lbl1' => $l1,
														'lbl2' => $l2,
														'match' => 'EXACT',
														'score' => 0};
								push @{$labelsToMatch1{$l1}}, $#matches;
								push @{$labelsToMatch2{$l2}}, $#matches;
								push @{$arg0ToMatch1{$a1}}, $#matches;
								push @{$arg0ToMatch2{$a2}}, $#matches;
								push @{$bestset->{'STATE'}}, 1;
								$bestset->{'SCORE'} -= $bestset->{'ARG01'}->{$a1};
								$bestset->{'SCORE'} -= $bestset->{'ARG02'}->{$a2}
									if $entails;
								$bestset->{'ARG01'}->{$a1} = 0;
								$bestset->{'ARG02'}->{$a2} = 0;
								$bestscore = $bestset->{'SCORE'};
							}
						}
					}
				}
			}
		}
	}
	
	my %results = ();
	if(scalar @sets == 1)
	{
		$results{'score'} = $unmatchedPenalty;
		return \%results;
	}
	else
	{
		my $finalscore = -1;
		$finalscore = $bestscore/$totallength if $totallength > 0.0;
		$results{'score'} = $finalscore;
		$results{'matches'} = [];
		for(my $m=0; $m <= $#matches; $m++)
		{
			if($bestset->{'STATE'}->[$m] == 1)
			{
				my $mrec = "$matches[$m]->{'lbl1'}:".
				$rmrs1->getRelByLabel($matches[$m]->{'lbl1'}).
				"\t$matches[$m]->{'lbl2'}:".
				$rmrs2->getRelByLabel($matches[$m]->{'lbl2'})."\t"
				.$matches[$m]->{'score'};

				push @{$results{'matches'}}, $mrec;
			}
		}
		$results{'unmatched1'} = [];
		foreach my $a1 (keys %{$bestset->{'ARG01'}})
		{
			if($bestset->{'ARG01'}->{$a1} != 0)
			{
				my $umrec = "";
				$umrec = "$a1: ";
				foreach my $l1 (@{$rmrs1->getLabelsByARG0($a1)})
				{
					$umrec .= "$l1-".$rmrs1->getRelByLabel($l1)." ";
				}
				push @{$results{'unmatched1'}}, $umrec;
			}
		}
		$results{'unmatched2'} = [];
		foreach my $a2 (keys %{$bestset->{'ARG02'}})
		{
			if($bestset->{'ARG02'}->{$a2} != 0)
			{
				my $umrec = "";
				$umrec = "$a2: ";
				foreach my $l2 (@{$rmrs2->getLabelsByARG0($a2)})
				{
					$umrec .= "$l2-".$rmrs2->getRelByLabel($l2)." ";
				}
				push @{$results{'unmatched2'}}, $umrec;
			}
		}
		return \%results;
	}
}

sub appendToPipeline {
	my ($obj, $matcher) = @_;
	if($matcher->isa('Delphin::Matcher'))
	{
		push @{$obj->{'Pipeline'}}, $matcher;
	}
	else
	{
		die "$matcher must be an object of type Delphin::Matcher";
	}
}

sub showPipeline {
	my $obj = $_[0];
	foreach my $m (@{$obj->{'Pipeline'}})
	{
		print $m->getName()." ";
	}
	print "\n";
}

sub deleteFromPipeline {
	my ($obj, $index) = @_;
	if($index < scalar @{$obj->{'Pipeline'}})
	{
		splice(@{$obj->{'Pipeline'}}, $index, 1);
	}
	else
	{
		die "Not a valid index";
	}
}

sub runPipeline {
	my ($obj, $rmrs1, $lbl1, $word1, $rmrs2, $lbl2, $word2) = @_;
	my $matchresult;
	foreach my $matcher (@{$obj->{'Pipeline'}})
	{
		if($matcher->precondition($rmrs1->getRelByLabel($lbl1),
			$rmrs2->getRelByLabel($lbl2)))
		{
			$matchresult = $matcher->match($rmrs1,$lbl1,$word1,$rmrs2,$lbl2,$word2);
			last if $matchresult->{'match'} ne "NOMATCH";
		}
	}

	return $matchresult;
}


sub removeFromArray($$)
{
   my($item, $arrref) = @_;
   my $i;
   for($i=0; $i < scalar @{$arrref}; $i++){last if ${$arrref}[$i] eq $item;}
   splice @{$arrref}, $i, 1;
}

1;
__END__

=head1 NAME

Delphin::Comparator - module for comparing two Delphin::RMRS objects

=head1 SYNOPSIS

  use Delphin::Comparator;

  my $comparator = Delphin::Comparator->new();

  $comparator->showPipeline();
  my $NEmatcher = Delphin::Matcher_myNEmatcher->new();
  $comparator->appendToPipeline($NEmatcher);
  $comparator->showPipeline();

  my $results = $comparator->compare($rmrs1, $rmrs2);

  print "Score: ".$results->{'score'}."\n";
  print "Matched\n";
  foreach my $m (@{$results->{'matches'}})
  {
	  print "$m\n";
  }
  print "\nUnmatched 1\n";
  foreach my $m (@{$results->{'unmatched1'}})
  {
	  print "$m\n";
  }
  print "\nUnmatched 2\n";
  foreach my $m (@{$results->{'unmatched2'}})
  {
	  print "$m\n";
  }

=head1 DESCRIPTION

A Comparator object sets up how two RMRS objects will be compared, and defines a
compare() method to compare them.

The constructor takes no arguments, but various options and weights can be set
after initialisation:

  $entails: defaults to 0. Setting this to 1 changes the score 
    calculation so that only unmatched predicates in the first 
    RMRS affect the score, unmatched predicates in the second RMRS 
    are ignored. 
  $nonEXACTscale: defaults to 0.5, scales the penalty score (where 
    the scale for EXACT matches is 1) incurred by argument 
    mismatches. The logic here is that potentially argument 
    mismatches should be taken more seriously where otherwise the 
    predicates match EXACTly, but it can be set to give whatever 
    effect you prefer. 
  @argMatch: defaults to (-0.5, -0.5, -0.5, -0.5), scores for ARG1, 
    ARG2, ARG3 and ARG4 respectively. This is the adjustment 
    (improvement if negative) of the score of a match when a match 
    is also found between the respective ARGn values.
  @argUnmatch: defaults to (1.5, 1.5, 1.5, 1.5), scores for ARG1, 
    ARG2, ARG3 and ARG4 respectively. This is the adjustment of the 
    score of a match when no match is found between the repective 
    ARGn values. Only triggered if both predicates of the match have 
    the ARGn value instantiated.
  $RealWeight: defaults to 1. Weight (when calculating the length of 
    an RMRS to find the average match score) of a REALPRED type 
    predicate.
  $GpredWeight: defaults to 0.1. Allows for the idea that GPRED type 
    predicates potentially should not have the same impact on a 
    comparison as REALPREDs. If all predicates should be treated 
    equally, set this to the same value as $RealWeight.
  $unmatchedPenalty: defaults to 3. The score of an unmatched predicate. 
    This will (usually) work out to be the highest score possible (where 
    high is bad).


The Comparator object has a match Pipeline that can have different Matcher
objects added to it. The default has only a Delphin::Matcher object. Other
Matcher subclass objects can be added to the pipeline using the
appendToPipeline() method. Methods showPipeline() and deletefromPipeline() are
also available for manipulating the pipeline. Matcher are tried in order until a
match is found, so 'fuzzier' Matchers should be listed later in the pipeline.

The compare() method takes two RMRS objects and returns a reference to a results
structure. This results structure is a hash with the following keys:

  {score}: the final comparison score (between 0 and $unmatchedPenalty)
  {matches}: a reference to an array of matchrecords for the matched 
    predicates
  {unmatched1}: a reference to an array of unmatchedrecords for the 
    unmatched predicates from RMRS1
  {unmatched2}: a reference to an array of unmatchedrecords for the 
    unmatched predicates from RMRS2

A matchrecord is a string showing the label and relname of the two predicates
that match, and the score of that match.

An unmatchedrecord is a string showing any unmatched predicates, grouped by
ARG0, so all predicates with the same ARG0 are in the same unmatchedrecord.

The compare() method is based on comparison code included in the LKB
(www.delph-in.net/lkb). It has three basic stages. First all real predicates in
one RMRS are matched against all real predicates in the second RMRS, using the
Comparator pipeline. At this stage there is a list of predicate matches, their
scores and types. One predicate may feature in more than one match.

The second stage looks at the ARGn values to alter the scores of the matches.
First the GPRED predicates that are co-referentially indexed (share an ARG0)
with each predicate in a match are compared, and a penalty added to the match
score if each predicate doesn't have the same associated GPREDs.

Second the ARG1, ARG2, ARG3 and ARG4 values of each predicate in a match are
examined to see if a match exists between the indexed predicates. If there is no
match, a penalty can be added to the match score. If there is a match, this may
decrease the match score (but not below zero), depending on the value of 
@argMatch. If only one predicate of a match has the ARGn value instantiated, no
change is made to the match score.

At this stage, the number of matches hasn't changed, but the scores of the
matches may have. The final stage works out the combination of matches that has
the best (lowest) score, where the score is calculated by averaging the match
scores, with an unmatched predicate contributing a weight of $unmatchedPenalty.
Each combination may only have each predicate listed once. The algorithm for
calculating the best set is a variation on the branch and bound algorithm,
gradually adding or not adding matches as long as the conditions hold.

If more than one combination of matches has the same score, the first one
calculated will be returned.


=head2 EXPORT

None by default.

=head1 BUGS

Probably :) Please let me know.

=head1 SEE ALSO

Delphin::RMRS - base class defining the RMRS object

Delphin::RMRS_XML - create RMRS objects from an XML file

Delphin::RMRS_DB - create RMRS objects from a database record

Delphin::Matcher - base class for Matcher objects for the Comparator pipeline

=head1 AUTHOR

Rebecca Dridan, E<lt>rdrid@dridan.comE<gt>

=head1 COPYRIGHT AND LICENSE

Copyright (C) 2006 by Rebecca Dridan

This library is free software; you can redistribute it and/or modify
it under the same terms as Perl itself, either Perl version 5.8.6 or,
at your option, any later version of Perl 5 you may have available.


=cut
