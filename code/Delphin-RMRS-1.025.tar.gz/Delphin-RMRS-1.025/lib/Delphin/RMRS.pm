package Delphin::RMRS;

use 5.008;
use strict;
use warnings;

use Encode;

require Exporter;

our @ISA = qw(Exporter);

our %EXPORT_TAGS = ( );
our @EXPORT_OK = ( );
our @EXPORT = qw( );

our $VERSION = sprintf "%d.%03d", q$Revision: 1.25 $ =~ /: (\d+)\.(\d+)/;

# Preloaded methods go here.

sub new {
	my ($pkg, $source, $id1, $id2, $id3) = @_;
	my %rmrs;
	$rmrs{'text'} = "";
	$rmrs{'enc'} = "utf-8";
	$rmrs{'tokenType'} = "char";
	$rmrs{'countType'} = "tok";
	$rmrs{'eps'} = ();
	$rmrs{'hcons'} = ();
	$rmrs{'ing'} = ();
	$rmrs{'arg0s'} = ();

	my $obj = \%rmrs;
	bless $obj, $pkg;

	return $obj;
}

sub getWord {
	my ($obj, $lbl) = @_;
	if(defined $obj->{'eps'}->{$lbl}->{'BASE'} and 
		$obj->{'eps'}->{$lbl}->{'BASE'} ne "")
	{
		my $word = $obj->{'eps'}->{$lbl}->{'BASE'};
		eval{
			$word = Encode::decode($obj->{'enc'}, $word) if $obj->{'enc'} ne "utf-8";
		};
		return $word;
	}
	else
	{
		return "";
	}
}
	
sub getEPbyLabel {
	my ($obj, $label) = @_;
	return $obj->{'eps'}->{$label};
}

sub getLabelsByARG0 {
	my ($obj, $arg0) = @_;
	return $obj->{'arg0s'}->{$arg0};
}

sub getRelByLabel {
	my ($obj, $lbl) = @_;
	return $obj->{'eps'}->{$lbl}->{'REL'};
}

sub getTypeByLabel {
	my ($obj, $lbl) = @_;
	return $obj->{'eps'}->{$lbl}->{'PTYPE'};
}

sub getCFROMbyLabel {
	my ($obj, $lbl) = @_;
	return $obj->{'eps'}->{$lbl}->{'CFROM'};
}

sub getCTObyLabel {
	my ($obj, $lbl) = @_;
	return $obj->{'eps'}->{$lbl}->{'CTO'};
}

sub getHCONSbyLabel {
	my ($obj, $lbl) = @_;
	return $obj->{'hcons'}->{$lbl};
}
	
sub getINGbyLabel {
	my ($obj, $lbl) = @_;
	return $obj->{'ing'}->{$lbl};
}
	
sub getCARGByLabel {
	my ($obj, $lbl) = @_;
	return $obj->{'eps'}->{$lbl}->{'CARG'};
}

sub getARG0s {
	my $obj = $_[0];
	return $obj->{'arg0s'};
}

sub getARG0ByLabel {
	my ($obj, $lbl) = @_;
	return $obj->{'eps'}->{$lbl}->{'ARG0'};
}

sub getARGxByLabel {
	my ($obj, $lbl, $x) = @_;
	return $obj->{'eps'}->{$lbl}->{"ARG$x"} if defined
		$obj->{'eps'}->{$lbl}->{"ARG$x"};
	return 0;
}

sub isReal {
	my ($obj, $l)  = @_;
	if((defined $obj->{'eps'}->{$l}->{'PTYPE'} and 
		$obj->{'eps'}->{$l}->{'PTYPE'} eq "REALPRED") or
		defined $obj->{'eps'}->{$l}->{'CARG'} or
		(defined $obj->{'eps'}->{$l}->{'REL'} and 
		$obj->{'eps'}->{$l}->{'REL'} =~ /^generic/))
	{
		return 1;
	}
	return 0;
}

sub isLabel {
	my ($obj, $arg) = @_;
	if($arg =~ /^[xe]/)
	{
		return 0;
	}
	return 1;
}

sub getLabels {
	my $obj = $_[0];
	my $labels = [];
	foreach my $l (keys %{$obj->{'eps'}})
	{
		push @{$labels}, $l;
	}
	return $labels;
}

sub getRealLabels {
	my $obj = $_[0];
	my $labels = [];
	foreach my $l (keys %{$obj->{'eps'}})
	{
		if(isReal($obj, $l))
		{
			push @{$labels}, $l;
		}
	}

	return $labels;
}

1;
__END__

=head1 NAME

Delphin::RMRS - class providing access to the RMRS object attributes and output
methods

=head1 SYNOPSIS

  use Delphin::RMRS;

=head1 DESCRIPTION

Describes an RMRS object, and provides methods to access various attributes of
the RMRS. The structure of the object is a hash with the following keys:

  {text}: stores the surface text of the whole RMRS, if it can be 
    determined
  {enc}: the encoding of surface forms in the RMRS, defaults to utf-8
  {tokenType}: char or word, relates to how CFROM and CTO are being used
  {countType}: tok or pos, relates to how CFROM and CTO are being used
  {eps}: a hash ref storing all EPs, keyed by label
  {hcons}: a hash ref storing all HCONS, keyed by L_HNDL
  {ing}: a hash ref storing all ING, keyed by ING-A
  {arg0s}: a hash ref, keyed on ARG0, that holds labels of all EPs with 
    that ARG0
	
Other descriptive keys can be added.

An EP is a hash ref that may contain the following keys:

  {LBL}: EP label, unique, hence used as a key, required
  {REL}: relation name, required
  {CFROM}: offset of start of EP within RMRS surface string, semantics 
    depend on tokenType and countType 
  {CTO}: offset of end of EP within RMRS surface string, semantics 
    depend on tokenType and countType	
  {BASE}: surface form of EP
  {PTYPE}: GPRED or REALPRED, required
  {CARG}: holds the CARG value
  {ARG0}: holds the ARG0 value, required?
  {ARG1}: holds the ARG1 value
  {ARG2}: holds the ARG2 value
  {ARG3}: holds the ARG3 value
  {ARG4}: holds the ARG4 value


=head2 EXPORT

None by default.

=head1 SEE ALSO

Delphin::RMRS_XML: creates an RMRS object from a XML input file

Delphin::RMRS_DB: creates an RMRS object from a database record

Delphin::Comparator: compares RMRS objects

=head1 AUTHOR

Rebecca Dridan, E<lt>rdrid@dridan.comE<gt>

=head1 COPYRIGHT AND LICENSE

Copyright (C) 2006 by Rebecca Dridan

This library is free software; you can redistribute it and/or modify
it under the same terms as Perl itself, either Perl version 5.8.6 or,
at your option, any later version of Perl 5 you may have available.


=cut
