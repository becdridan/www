package Delphin::RMRS_XML;

use 5.008;
use strict;
use warnings;

use XML::Twig;

require Exporter;
require Delphin::RMRS;

our @ISA = qw(Exporter Delphin::RMRS);

our %EXPORT_TAGS = ( ); 
our @EXPORT_OK = ( );
our @EXPORT = qw( );

our $VERSION =  sprintf "%d.%03d", q$Revision: 1.8 $ =~ /: (\d+)\.(\d+)/;

my %obj = ();
my $tok = 0;
my $word = 1;
my $labeladd;

sub new {
	my ($pkg, $file) = @_;

	$obj{'text'} = "";
	$obj{'enc'} = "utf-8";
	$obj{'tokenType'} = "char"; #char or word
	$obj{'countType'} = "tok"; #tok or pos
	$obj{'eps'} = ();
	$obj{'hcons'} = ();
	$obj{'arg0s'} = ();

	$labeladd = 0;
	my $twig = XML::Twig->new( twig_handlers => {'rmrs' => \&process_rmrs});
	$twig->parsefile($file);
	$twig->purge();

	$obj{'countType'} = "pos" if(!$tok);
	$obj{'tokenType'} = "word" if $word;

	my %obj_copy = %obj;
	my $rmrs = \%obj_copy;
   bless $rmrs, $pkg;
   return $rmrs;
}

sub process_rmrs(&&) {
	my ($t, $rmrs) = @_;
	my ($id1, $id2, $id3) = split /:/, $rmrs->att('ident') if defined
		$rmrs->att('ident');

	$obj{'text'} = $rmrs->att('surface');

	my $label = $rmrs->first_child('label');
	process_label($label) if defined $label;

	my @eps = $rmrs->children('ep');
	foreach my $ep (@eps) {
		process_ep($ep);
	}

	my @rargs = $rmrs->children('rarg');
	foreach my $rarg (@rargs) {
		process_rarg($rarg);
	}

	my @ings = $rmrs->children('ing');
	foreach my $ing (@ings) {
		process_ing($ing);
	}

	my @hconss = $rmrs->children('hcons');
	foreach my $hcons (@hconss) {
		process_hcons($hcons);
	}

	$_->delete;

	$labeladd+=100;
}

sub process_label($) {
	my $label = $_[0];
}

sub process_ep($) {
	my $ep = $_[0];
	my $labelref = $ep->first_child('label');
	my $lblnum = $labelref->att('vid');
	$lblnum += $labeladd;
	my $label = "h".$lblnum;
	$obj{'eps'}->{$label} = ();
	$obj{'eps'}->{$label}->{'LBL'} = $label;
	my $rel;

	my $pred = $ep->first_child('gpred');
	if(defined $pred)
	{
		$obj{'eps'}->{$label}->{'PTYPE'} = "GPRED";
		$rel = $pred->text;
	}
	else
	{
		$obj{'eps'}->{$label}->{'PTYPE'} = "REALPRED";
		$pred = $ep->first_child('realpred');
		if(defined $pred)
		{
			$rel = $pred->att('lemma');
			if(defined $pred->att('pos'))
			{
				$rel .= "_".$pred->att('pos');
				if(defined $pred->att('sense'))
				{
					$rel .= "_".$pred->att('sense');
				}
			}
		}
	}
	$obj{'eps'}->{$label}->{'REL'} = $rel;
	$obj{'eps'}->{$label}->{'CFROM'} = $ep->att('cfrom');
	$obj{'eps'}->{$label}->{'CTO'} = $ep->att('cto');
	if(defined $ep->att('base') and $ep->att('base') ne "")
	{
		$obj{'eps'}->{$label}->{'BASE'} = $ep->att('base');
	}
	else
	{
		$obj{'eps'}->{$label}->{'BASE'} = $ep->att('surface');
	}
	if(defined $obj{'eps'}->{$label}->{'BASE'})
	{
		if($ep->att('cto') == $ep->att('cfrom'))
		{
			$tok = 1;
		}
		if(($ep->att('cto') - $ep->att('cfrom')) > 1 and 
			length($obj{'eps'}->{$label}->{'BASE'}) > 0)
		{
			$word = 0;
		}
	}


	my $var = $ep->first_child('var');
	$lblnum = $var->att('vid');
	$lblnum += $labeladd;
	my $val = $var->att('sort').$lblnum;
	$obj{'eps'}->{$label}->{'ARG0'} = $val;
	$obj{'arg0s'}->{$val} = [] if ! defined $obj{'arg0s'}->{$val};
	push @{$obj{'arg0s'}->{$val}}, $label;
}

sub process_rarg($) {
	my $rarg = $_[0];
	my $name = $rarg->first_child('rargname')->text;
	$name =~ s/-/_/g;

	my $val;

	if($name eq "CARG")
	{
		$val = $rarg->first_child('constant')->text;
	}
	else
	{
		my $var = $rarg->first_child('var');
		if($var->att('vid') =~ /\d/)
		{
			my $lblnum = $var->att('vid');
			$lblnum += $labeladd;
			$val = $var->att('sort').$lblnum;
		}
	}
	my $labelref = $rarg->first_child('label');

	if(defined $val and $labelref->att('vid') =~ /\d/ 
		and ($name eq "CARG" or $val =~ /\d/))
	{
		my $lblnum = $labelref->att('vid');
		$lblnum += $labeladd;
		my $label = "h".$lblnum;
		$obj{'eps'}->{$label}->{$name} = $val;
	}
}

sub process_ing {
	my $ing = $_[0];

}

sub process_hcons {
	my $hcons = $_[0];

	my $rel = $hcons->att('hreln');
	my $hi = $hcons->first_child('hi');
	my $var = $hi->first_child('var');
	if(defined $var->att('vid') and $var->att('vid') =~ /\d/)
	{
		my $lblnum = $var->att('vid');
		$lblnum += $labeladd;
		my $lhndl = $var->att('sort').$lblnum;
		$obj{'hcons'}->{$lhndl} = [] if ! defined $obj{'hcons'}->{$lhndl};

		my %ref = ();
		$ref{'L_HNDL'} = $lhndl;
		$ref{'REL'} = $rel;

		my $lo = $hcons->first_child('lo');
		my $labelref = $lo->first_child('label');
		if(defined $labelref->att('vid') and $labelref->att('vid') =~ /\d/)
		{
			$lblnum = $labelref->att('vid');
			$lblnum += $labeladd;
			$ref{'R_HNDL'} = "h".$lblnum;
			push @{$obj{'hcons'}->{$lhndl}}, \%ref;
		}
	}
}

1;
__END__

=head1 NAME

Delphin::RMRS_XML - RMRS sub-class for creating RMRS objects from XML

=head1 SYNOPSIS

  use Delphin::RMRS_XML;

  my $rmrs1 = Delphin::RMRS_XML->new("rmrs1.xml");

=head1 DESCRIPTION

Creates an RMRS structure, as defined in Delphin::RMRS, from an XML file that
complies to the DTD given in:
  Copestake, Ann. 2004. Robust Minimal Recursion Semantics
  Working Paper
  http://www.cl.cam.ac.uk/~aac10/papers/rmrsdraft.pdf
	

=head2 EXPORT

None by default.


=head1 SEE ALSO

Delphin::RMRS - base class

Delphin::RMRS_DB - creates RMRS objects from database records

Delphin::Comparator - compares two RMRS objects

=head1 BUGS

Attempts to guess the tokenType and countType, but doesn't always get it
correct. If these are known, programs should set them after creating the RMRS:

  $rmrs1->{tokenType} = "word";
  $rmrs1->{countType} = "pos";

Adds all EPs in the file to the same RMRS object, even if there are multiple
overlapping RMRSs defined in the file. This will be fixed when I work out what
the appropriate behaviour should be in this case.

=head1 AUTHOR

Rebecca Dridan, E<lt>rdrid@dridan.comE<gt>

=head1 COPYRIGHT AND LICENSE

Copyright (C) 2006 by Rebecca Dridan

This library is free software; you can redistribute it and/or modify
it under the same terms as Perl itself, either Perl version 5.8.6 or,
at your option, any later version of Perl 5 you may have available.


=cut
